package com.salesmanagement.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db;
    LinearLayout root, content;
    TextView summary;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        root = new LinearLayout(this); root.setOrientation(1);
        root.setPadding(18,18,18,18); root.setBackgroundColor(0xFFF4F6F8);
        TextView title = new TextView(this); title.setText("إدارة المبيعات"); title.setTextSize(26);
        title.setTypeface(null, Typeface.BOLD); title.setTextColor(0xFF183153);
        root.addView(title);
        summary = new TextView(this); summary.setTextSize(15); summary.setPadding(0,12,0,12); root.addView(summary);
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        LinearLayout nav = new LinearLayout(this);
        String[] tabs={"الرئيسية","المنتجات","العملاء","بيع جديد","سجل المبيعات"};
        for(String t:tabs){ Button x=button(t); nav.addView(x); x.setOnClickListener(v->show(t)); }
        hsv.addView(nav); root.addView(hsv);
        content = new LinearLayout(this); content.setOrientation(1); root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root); show("الرئيسية");
    }
    Button button(String s){ Button b=new Button(this); b.setText(s); return b; }
    void show(String tab){
        content.removeAllViews(); summary.setText("نسخة أولية تعمل على الجهاز — البيانات محفوظة محليًا");
        if(tab.equals("الرئيسية")){
            addText("لوحة المتابعة",22,true);
            addText("إجمالي الفواتير: "+db.count("sales"),18,false);
            addText("عدد المنتجات: "+db.count("products"),18,false);
            addText("عدد العملاء: "+db.count("customers"),18,false);
            addText("ابدأ بإضافة المنتجات والعملاء ثم سجّل عملية البيع.",16,false);
        } else if(tab.equals("المنتجات")) {
            addText("المنتجات",22,true);
            EditText n=field("اسم المنتج"); EditText p=field("سعر البيع"); EditText q=field("الكمية");
            add(n); add(p); add(q);
            addButton("حفظ المنتج",()->{ if(n.getText().length()==0)return; db.exec("INSERT INTO products(name,price,qty) VALUES(?,?,?)",new Object[]{n.getText().toString(),num(p),num(q)}); show(tab); });
            list("products");
        } else if(tab.equals("العملاء")) {
            addText("العملاء",22,true); EditText n=field("اسم العميل"); EditText phone=field("رقم الهاتف");
            add(n); add(phone);
            addButton("حفظ العميل",()->{ if(n.getText().length()==0)return; db.exec("INSERT INTO customers(name,phone) VALUES(?,?)",new Object[]{n.getText().toString(),phone.getText().toString()}); show(tab); });
            list("customers");
        } else if(tab.equals("بيع جديد")) {
            addText("تسجيل بيع مباشر",22,true);
            ArrayList<String> names=new ArrayList<>(); ArrayList<Integer> ids=new ArrayList<>();
            Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name FROM products ORDER BY name",null);
            while(c.moveToNext()){ids.add(c.getInt(0)); names.add(c.getString(1));} c.close();
            if(names.isEmpty()){addText("أضف منتجًا أولًا من قسم المنتجات.",16,false);return;}
            Spinner sp=new Spinner(this); sp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names)); add(sp);
            EditText customer=field("اسم العميل (اختياري)"); EditText qty=field("الكمية"); EditText price=field("سعر الوحدة");
            add(customer); add(qty); add(price);
            addButton("حفظ الفاتورة",()->{ int i=sp.getSelectedItemPosition(); int amount=(int)num(qty); double unit=num(price); if(amount<1||unit<=0)return;
                db.exec("INSERT INTO sales(product_id,product_name,customer,qty,unit_price,total,date) VALUES(?,?,?,?,?,?,?)",
                    new Object[]{ids.get(i),names.get(i),customer.getText().toString(),amount,unit,amount*unit,new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date())});
                db.exec("UPDATE products SET qty=qty-? WHERE id=?",new Object[]{amount,ids.get(i)}); show(tab);
            });
        } else {
            addText("سجل المبيعات",22,true);
            Cursor c=db.getReadableDatabase().rawQuery("SELECT product_name,customer,qty,total,date FROM sales ORDER BY id DESC",null);
            while(c.moveToNext()) addText(c.getString(0)+" | "+c.getString(1)+" | كمية: "+c.getInt(2)+" | إجمالي: "+c.getDouble(3)+" ج.م\n"+c.getString(4),15,false);
            c.close();
        }
    }
    double num(EditText e){try{return Double.parseDouble(e.getText().toString());}catch(Exception ex){return 0;}}
    EditText field(String hint){EditText e=new EditText(this); e.setSingleLine(); e.setHint(hint); return e;}
    void add(View v){content.addView(v);}
    void addText(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xFF263445);t.setPadding(4,12,4,12);if(bold)t.setTypeface(null,Typeface.BOLD);content.addView(t);}
    void addButton(String s,Runnable r){Button b=button(s);content.addView(b);b.setOnClickListener(v->r.run());}
    void list(String table){
        Cursor c=db.getReadableDatabase().rawQuery(table.equals("products")?"SELECT name,price,qty FROM products ORDER BY id DESC":"SELECT name,phone FROM customers ORDER BY id DESC",null);
        while(c.moveToNext()) addText(table.equals("products")?c.getString(0)+" — "+c.getDouble(1)+" ج.م — مخزون: "+c.getInt(2):c.getString(0)+" — "+c.getString(1),15,false);
        c.close();
    }
    class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"sales.db",null,1);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,price REAL,qty INTEGER)");
            d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT)");
            d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,product_name TEXT,customer TEXT,qty INTEGER,unit_price REAL,total REAL,date TEXT)");
        }
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
        void exec(String sql,Object[] a){SQLiteDatabase d=getWritableDatabase(); android.database.sqlite.SQLiteStatement s=d.compileStatement(sql);
            for(int i=0;i<a.length;i++){Object v=a[i]; if(v instanceof Integer)s.bindLong(i+1,(Integer)v);else if(v instanceof Double)s.bindDouble(i+1,(Double)v);else s.bindString(i+1,String.valueOf(v));} s.executeInsert();}
        int count(String t){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+t,null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
    }
}
